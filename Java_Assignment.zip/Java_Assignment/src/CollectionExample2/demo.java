package CollectionExample2;

public class demo {
    public static void main(String[] args) {
        String S = "Hello";
        String S1 = "hello";
        System.out.println(S.compareTo(S1));
    }
}
