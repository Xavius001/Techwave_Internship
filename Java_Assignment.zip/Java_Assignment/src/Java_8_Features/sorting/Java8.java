package Java_8_Features.sorting;

public class Java8 {

}
