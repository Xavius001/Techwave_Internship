package org.example.dao;

public class TeamDbOperations {

}
