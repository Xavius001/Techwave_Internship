public class First {
    public static void main(String[] args) {
        char ch = 'd';
        switch(ch) {
            case 'a': System.out.println("the character is a"); break;
            case 'b': System.out.println("the character is b"); break;
            case 'c': System.out.println("the character is c"); break;
            default: System.out.println("Nothing"); break;
        }
    }
}